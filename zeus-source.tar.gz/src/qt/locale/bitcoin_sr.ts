<TS language="sr" version="2.1">
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Right-click to edit address or label</source>
        <translation>Kliknite desnim klikom radi izmene adrese ili oznake</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation>Napravite novu adresu</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation>Novo</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>Kopirajte trenutno izabranu adresu</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>Kopirajte</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>Zatvorite</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation>Izbrisite trenutno izabranu adresu sa liste</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>Eksportuj podatke iz izabrane kartice u fajl</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>&amp;Избриши</translation>
    </message>
    <message>
        <source>Choose the address to send coins to</source>
        <translation>Izbirajte adresu za slanje</translation>
    </message>
    <message>
        <source>Choose the address to receive coins with</source>
        <translation>Izbirajte adresu za primanje</translation>
    </message>
    <message>
        <source>Sending addresses</source>
        <translation>Adresa za slanje</translation>
    </message>
    <message>
        <source>Receiving addresses</source>
        <translation>Adresa za primanje</translation>
    </message>
    </context>
<context>
    <name>AddressTableModel</name>
    </context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Enter passphrase</source>
        <translation>Унесите лозинку</translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation>Нова лозинка</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation>Поновите нову лозинку</translation>
    </message>
    </context>
<context>
    <name>BanTableModel</name>
    </context>
<context>
    <name>BitcoinGUI</name>
    <message>
        <source>Synchronizing with network...</source>
        <translation>Синхронизација са мрежом у току...</translation>
    </message>
    <message>
        <source>&amp;Overview</source>
        <translation>&amp;Општи преглед</translation>
    </message>
    <message>
        <source>Show general overview of wallet</source>
        <translation>Погледајте општи преглед новчаника</translation>
    </message>
    <message>
        <source>&amp;Transactions</source>
        <translation>&amp;Трансакције</translation>
    </message>
    <message>
        <source>Browse transaction history</source>
        <translation>Претражите историјат трансакција</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation>I&amp;zlaz</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation>Напустите програм</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>О &amp;Qt-у</translation>
    </message>
    <message>
        <source>Show information about Qt</source>
        <translation>Прегледајте информације о Qt-у</translation>
    </message>
    <message>
        <source>&amp;Options...</source>
        <translation>П&amp;оставке...</translation>
    </message>
    <message>
        <source>&amp;Encrypt Wallet...</source>
        <translation>&amp;Шифровање новчаника...</translation>
    </message>
    <message>
        <source>&amp;Backup Wallet...</source>
        <translation>&amp;Backup новчаника</translation>
    </message>
    <message>
        <source>&amp;Change Passphrase...</source>
        <translation>Промени &amp;лозинку...</translation>
    </message>
    <message>
        <source>Send coins to a Bitcoin address</source>
        <translation>Пошаљите новац на zeus адресу</translation>
    </message>
    <message>
        <source>Change the passphrase used for wallet encryption</source>
        <translation>Мењање лозинке којом се шифрује новчаник</translation>
    </message>
    <message>
        <source>Wallet</source>
        <translation>новчаник</translation>
    </message>
    <message>
        <source>&amp;Send</source>
        <translation>&amp;Пошаљи</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Фајл</translation>
    </message>
    <message>
        <source>&amp;Settings</source>
        <translation>&amp;Подешавања</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>П&amp;омоћ</translation>
    </message>
    <message>
        <source>Tabs toolbar</source>
        <translation>Трака са картицама</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Greška</translation>
    </message>
    <message>
        <source>Up to date</source>
        <translation>Ажурно</translation>
    </message>
    <message>
        <source>Catching up...</source>
        <translation>Ажурирање у току...</translation>
    </message>
    <message>
        <source>Sent transaction</source>
        <translation>Послана трансакција</translation>
    </message>
    <message>
        <source>Incoming transaction</source>
        <translation>Придошла трансакција</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</source>
        <translation>Новчаник јс &lt;b&gt;шифрован&lt;/b&gt; и тренутно &lt;b&gt;откључан&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation>Новчаник јс &lt;b&gt;шифрован&lt;/b&gt; и тренутно &lt;b&gt;закључан&lt;/b&gt;</translation>
    </message>
    </context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>Amount:</source>
        <translation>Iznos:</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>iznos</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>datum</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Potvrdjen</translation>
    </message>
    </context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <source>Edit Address</source>
        <translation>Измени адресу</translation>
    </message>
    <message>
        <source>&amp;Label</source>
        <translation>&amp;Етикета</translation>
    </message>
    <message>
        <source>&amp;Address</source>
        <translation>&amp;Адреса</translation>
    </message>
    </context>
<context>
    <name>FreespaceChecker</name>
    </context>
<context>
    <name>HelpMessageDialog</name>
    <message>
        <source>version</source>
        <translation>верзија</translation>
    </message>
    <message>
        <source>Usage:</source>
        <translation>Korišćenje:</translation>
    </message>
    </context>
<context>
    <name>Intro</name>
    <message>
        <source>Error</source>
        <translation>Greška</translation>
    </message>
    </context>
<context>
    <name>ModalOverlay</name>
    <message>
        <source>Form</source>
        <translation>Форма</translation>
    </message>
    </context>
<context>
    <name>OpenURIDialog</name>
    </context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation>Поставке</translation>
    </message>
    <message>
        <source>W&amp;allet</source>
        <translation>новчаник</translation>
    </message>
    <message>
        <source>&amp;Unit to show amounts in:</source>
        <translation>&amp;Јединица за приказивање износа:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    </context>
<context>
    <name>OverviewPage</name>
    <message>
        <source>Form</source>
        <translation>Форма</translation>
    </message>
    </context>
<context>
    <name>PaymentServer</name>
    </context>
<context>
    <name>PeerTableModel</name>
    </context>
<context>
    <name>QObject</name>
    <message>
        <source>Amount</source>
        <translation>iznos</translation>
    </message>
    </context>
<context>
    <name>QObject::QObject</name>
    </context>
<context>
    <name>QRImageWidget</name>
    </context>
<context>
    <name>RPCConsole</name>
    <message>
        <source>Yes</source>
        <translation>Da</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Ne</translation>
    </message>
    </context>
<context>
    <name>ReceiveCoinsDialog</name>
    <message>
        <source>&amp;Amount:</source>
        <translation>Iznos:</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>&amp;Етикета</translation>
    </message>
    <message>
        <source>&amp;Message:</source>
        <translation>Poruka:</translation>
    </message>
    <message>
        <source>Show</source>
        <translation>Prikaži</translation>
    </message>
    </context>
<context>
    <name>ReceiveRequestDialog</name>
    <message>
        <source>Copy &amp;Address</source>
        <translation>Kopirajte adresu</translation>
    </message>
    </context>
<context>
    <name>RecentRequestsTableModel</name>
    </context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <source>Send Coins</source>
        <translation>Слање новца</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Iznos:</translation>
    </message>
    <message>
        <source>Confirm the send action</source>
        <translation>Потврди акцију слања</translation>
    </message>
    <message>
        <source>S&amp;end</source>
        <translation>&amp;Пошаљи</translation>
    </message>
    </context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <source>A&amp;mount:</source>
        <translation>Iznos:</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>&amp;Етикета</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+П</translation>
    </message>
    <message>
        <source>Message:</source>
        <translation>Poruka:</translation>
    </message>
    </context>
<context>
    <name>SendConfirmationDialog</name>
    <message>
        <source>Yes</source>
        <translation>Da</translation>
    </message>
</context>
<context>
    <name>ShutdownWindow</name>
    </context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <source>Alt+A</source>
        <translation>Alt+</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+П</translation>
    </message>
    </context>
<context>
    <name>SplashScreen</name>
    <message>
        <source>[testnet]</source>
        <translation>[testnet]</translation>
    </message>
</context>
<context>
    <name>TrafficGraphWidget</name>
    </context>
<context>
    <name>TransactionDesc</name>
    </context>
<context>
    <name>TransactionDescDialog</name>
    <message>
        <source>This pane shows a detailed description of the transaction</source>
        <translation>Ovaj odeljak pokazuje detaljan opis transakcije</translation>
    </message>
    </context>
<context>
    <name>TransactionTableModel</name>
    </context>
<context>
    <name>TransactionView</name>
    </context>
<context>
    <name>UnitDisplayStatusBarControl</name>
    </context>
<context>
    <name>WalletFrame</name>
    </context>
<context>
    <name>WalletModel</name>
    </context>
<context>
    <name>WalletView</name>
    </context>
<context>
    <name>bitcoin-core</name>
    <message>
        <source>Options:</source>
        <translation>Opcije</translation>
    </message>
    <message>
        <source>Specify data directory</source>
        <translation>Gde je konkretni data direktorijum </translation>
    </message>
    <message>
        <source>Accept command line and JSON-RPC commands</source>
        <translation>Prihvati komandnu liniju i JSON-RPC komande</translation>
    </message>
    <message>
        <source>Run in the background as a daemon and accept commands</source>
        <translation>Radi u pozadini kao daemon servis i prihvati komande</translation>
    </message>
    <message>
        <source>Username for JSON-RPC connections</source>
        <translation>Korisničko ime za JSON-RPC konekcije</translation>
    </message>
    <message>
        <source>Password for JSON-RPC connections</source>
        <translation>Lozinka za JSON-RPC konekcije</translation>
    </message>
    <message>
        <source>Loading addresses...</source>
        <translation>učitavam adrese....</translation>
    </message>
    <message>
        <source>Insufficient funds</source>
        <translation>Nedovoljno sredstava</translation>
    </message>
    <message>
        <source>Loading block index...</source>
        <translation>Učitavam blok indeksa...</translation>
    </message>
    <message>
        <source>Loading wallet...</source>
        <translation>Новчаник се учитава...</translation>
    </message>
    <message>
        <source>Rescanning...</source>
        <translation>Ponovo skeniram...</translation>
    </message>
    <message>
        <source>Done loading</source>
        <translation>Završeno učitavanje</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Greška</translation>
    </message>
</context>
</TS>